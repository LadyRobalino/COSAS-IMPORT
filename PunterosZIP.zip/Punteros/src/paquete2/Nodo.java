
package paquete2;

public class Nodo {
    int dato;
    Nodo next;
    
    public Nodo (){
        dato = 0;
        next = null;
    }
    
    public Nodo (int a){
        dato = a;
        next = null;
    }
    
    public void contatenar (Nodo nod){
        next = nod;
    }
}
