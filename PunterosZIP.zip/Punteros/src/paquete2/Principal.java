
package paquete2;

public class Principal {
    public static void main(String[] args) {
        Nodo objA = new Nodo (8);
        System.out.println(objA);
        Nodo objB = new Nodo();
        System.out.println(objB);
        objA.contatenar(objB);
        System.out.println("Next A: " + objA.next);
       // objA.next.next = objC;
    }
}
