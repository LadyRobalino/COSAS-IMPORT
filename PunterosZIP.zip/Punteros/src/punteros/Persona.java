package punteros;
public class Persona {
    String nombre;
    int edad;
    
    public Persona (String n, int e){
        nombre = n;
        edad = e;
    }
    
    public void cambiarDatos (String nuevoNombre, int nuevaEdad){
        nombre = nuevoNombre;
        edad = nuevaEdad;
    }
    
    public void motrarDatos (){
        System.out.println("Nombre: " + nombre + "\n" + "Edad: " + edad + "\n");
    }
}
