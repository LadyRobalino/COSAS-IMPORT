package punteros;
public class Principal {
    public static void main(String[] args) {
        Persona personaA;
        Persona personaB;
        
        personaA = new Persona ("Ana", 22);
        personaB = new Persona ("Juan", 25);
        System.out.println("Imprimir personaA: " + personaA + "\n");
        System.out.println("Imprimir personaB: " + personaB + "\n");
        
        Persona personaC;
        personaC = new Persona("Kevin", 22);
        System.out.println("Imprimir personaC: " + personaC + "\n");
        
        personaC = personaA;
        System.out.println("Imprimir personaC: " + personaC + "\n");
        
        personaA.cambiarDatos("Doris", 33);
        personaA.motrarDatos();
        personaC.motrarDatos();
    }
}
